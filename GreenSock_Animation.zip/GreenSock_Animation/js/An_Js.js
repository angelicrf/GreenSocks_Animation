(function(){
  var tl_1 = new TimelineMax();
    tl_1.from('#text',2.5,{scale:2,opacity:0, ease: Elastic.easeOut})
    .from('#ad_First', 8, {left:-550, ease: Power3.easeOut},'-=0.5')
    .from('#ad_Fourth',9,{opacity:0.5})
    .to('#ad_Fourth',0.5,{opacity:0},'-=2');
    
   var tl_2 = new TimelineMax(); 
    tl_2.from('#ad_Fifth',5,{top:-300,opacity:0 ,ease: Bounce.easeOut})
    
    
}());